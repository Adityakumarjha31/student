const mysql2 = require('mysql2');

const connection = mysql2.createConnection({

    host:"localhost",
    database:"dac",
    user:"root",
    password:"cdacacts"
});

connection.connect((err)=>{
    if(err){
        console.log("ERROR CONNECTING TO DATABASE");
    }
    console.log("Connected to database");
});


module.exports=connection;