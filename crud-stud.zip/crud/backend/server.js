const express = require('express');
const cors = require('cors');
const port = 3001;
const db = require('./db');

const app=express();

 app.use(cors());
 app.use(express.json());

 
app.get('/getstudents',(req,res)=>{
    const sql = "select * from students";
    db.query(sql,(err,result)=>{
        if(err){
            res.status(500).send("erro sending data");
        }
        res.status(200).json(result);
    })
});




app.get('/getdept',(req,res)=>{
    const sql = "select * from dept";
    db.query(sql,(err,result)=>{
        if(err){
            res.status(500).send("erro sending data");
        }
        res.status(200).json(result);
    })
});



app.delete('/deletestudents/:id',(req,res)=>{
    const {id}=req.params;
    console.log("iddddddddd",id);
    const sql = "delete  from students where id =?";
    db.query(sql,[id],(err,result)=>{
        if(err){
            res.status(500).send("erro sending data");
        }
        res.status(200).json(result);
    })
})


app.put('/editstudent/:id',(req,res)=>{
    const {id}= req.params;
    console.log(req.body);
    const {name,email,course,address,mobile,dob,dept}=req.body;
    const sql = "UPDATE  students set name=?,email=?,course=?,Address=?,mobile=?,DOB=? ,dept=? where id=?";
    db.query(sql,[name,email,course,address,mobile,dob,dept,id],(err,result)=>{
        if(err){
            res.status(500).send("error fetching data");
        }
        res.status(200).json(result);
    })
})


app.post('/insertstudent',(req,res)=>{

    const {name,email,course,address,mobile,dob,dept}=req.body;
    const sql = "insert into students (name,email, course, Address, mobile, DOB,dept) values (?,?,?,?,?,?,?)";
    db.query(sql,[name,email,course,address,mobile,dob,dept],(err,result)=>{
        if(err){
            res.status(500).send("erro sending data");
        }
        res.status(200).json(result);
    })
});




app.listen(port,()=>{
console.log("Server is running in port ",port)
})