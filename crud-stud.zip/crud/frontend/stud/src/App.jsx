
import './App.css'
import { useState, useEffect, use } from 'react'
import axios from 'axios'
import 'bootstrap/dist/css/bootstrap.css';



function App() {

  const [students, setstudents] = useState([]);
  const [openform, setopenform] = useState(false);
  const [updateture, setupdatetrue] = useState(false);
  const [updateid, setupdateid] = useState();
  const [dept,setdept]=useState([])
  const [formdata, setformdata] = useState({
    name: "",
    email: "",
    course: "",
    address: "",
    mobile: "",
    dob: "",
    dept:""
  })


  function editformdata(student) {
    setupdateid(student.id);
    setopenform(true);
    setupdatetrue(true);
    console.log("herre", student);
    setformdata({
      name: student.name,
      email: student.email,
      course: student.course,
      address: student.Address,
      mobile: student.mobile,
      dob: student.DOB,
      dept:student.dept
    });
  }

  console.log("SEEE", dept)


  function handleonchange(e) {
    const { name, value } = e.target;
    setformdata({
      ...formdata,
      [name]: value,
    });
  }

  console.log("formdata", formdata);
  function handleopenform() {
    setopenform(prev => !prev)
    setformdata({
      name: "",
      email: "",
      course: "",
      address: "",
      mobile: "",
      dob: "",
      dept:""
  })
}



  async function editsubmit() {
    const response = await axios.put(`http://localhost:3001/editstudent/${updateid}`, formdata);
    setopenform(false)
    console.log(formdata)
    getstudent();
    setformdata({
      name: "",
      email: "",
      course: "",
      address: "",
      mobile: "",
      dob: "",
      dept:""
    });
  }

  async function handlesubmit() {
    const response = await axios.post('http://localhost:3001/insertstudent', formdata);
    console.log("im here", response.data.success);
    setopenform(false);
    getstudent();
    setformdata({
      name: "",
      email: "",
      course: "",
      address: "",
      mobile: "",
      dob: "",
      dept:""
    });
  }


  async function getstudent() {
    const response = await axios.get('http://localhost:3001/getstudents');
    console.log(response.data);
    const data = response.data;
    setstudents(data);
  };


  async function deletestud(id) {
    console.log("iddd", id);
    const response = await axios.delete(`http://localhost:3001/deletestudents/${id}`);
    console.log(response.data.success);
    getstudent();
  }

  console.log("students", students);


  useEffect(() => {
    getstudent();
    getdept();
  }, []);




  async function getdept() {
    const response = await axios.get('http://localhost:3001/getdept');
    console.log(response.data);
    const data = response.data;
    setdept(data);
  };




  return (
    <>
      <div className='container custom-bg p-4 rounded '>

        <div>
          <button className='btn addstud btn-warning ' onClick={handleopenform}>{!openform ? "Add Student" : "Close"}</button>
        </div>

        {openform &&


          <div className='form'>

            <input type='textbox' name="name" placeholder='name' value={formdata.name} onChange={handleonchange}></input>

            <input type='textbox' name="email" placeholder='email' value={formdata.email} onChange={handleonchange}></input>

            <input type='textbox' name="course" placeholder='course' value={formdata.course} onChange={handleonchange}></input>

            <input type='textbox' name="address" placeholder='address' value={formdata.address} onChange={handleonchange}></input>

            <input type='textbox' name="mobile" placeholder='mobile' value={formdata.mobile} onChange={handleonchange}></input>

            <input type='date' name="dob" value={formdata.dob} onChange={handleonchange}></input>


            <select className='dropdown' name="dept" value={formdata.dept} onChange={handleonchange}>
            <option value="null">Select</option>
              {
                dept.map((dept)=>{
                  return(
                   
                    <option key={dept.dept_id}>{dept.dept_name}</option>
                  )
                })  
              }
            </select>


            {updateture ? <button className='submitdata btn btn-primary' onClick={editsubmit}>Update Student</button> : <button className='submitdata btn btn-primary' onClick={handlesubmit}>Add Student</button>}



          </div>


        }

        <table className='table '>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Course</th>
              <th>Address</th>
              <th>Mobile</th>
              <th>Dob</th>
              <th>Dept</th>
              <th colSpan={2}>Actions</th>

            </tr>
          </thead>
          <tbody>
            {students.map(stud => (
              <tr key={stud.id}>
                <td>{stud.name}</td>
                <td>{stud.email}</td>
                <td>{stud.course}</td>
                <td>{stud.Address}</td>
                <td>{stud.mobile}</td>
                <td>{stud.DOB}</td>
                <td>{stud.dept}</td>

                <td><div><button className='btn btn-primary' onClick={() => editformdata(stud)}>EDIT</button></div></td>
                <td><div><button className='btn btn-danger' onClick={() => deletestud(stud.id)}>Delete</button></div></td>
              </tr>
            ))}

          </tbody>
        </table>

      </div>



    </>
  )
}

export default App
